const landingPageData = {
    about: "I am a skilled front-end developer experienced in creating visually stunning and user-friendly websites and applications. I use UI/UX design principles to deliver high-quality products that meet client expectations.",  
  };

export default landingPageData;
